﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SnowBack.Migrations
{
    /// <inheritdoc />
    public partial class UpdateMyClasses : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "good",
                table: "J_Transport_Fueling");

            migrationBuilder.DropColumn(
                name: "point",
                table: "J_Transport_Fueling");

            migrationBuilder.DropColumn(
                name: "started",
                table: "J_Transport_Fueling");

            migrationBuilder.DropColumn(
                name: "code",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropColumn(
                name: "dayOrder",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropColumn(
                name: "nightorder",
                table: "J_SnowGuns_Orders");

            migrationBuilder.RenameColumn(
                name: "task",
                table: "J_Transport_Fueling",
                newName: "gasstation");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "J_Transport_Fueling",
                newName: "fueltype");

            migrationBuilder.RenameColumn(
                name: "Comment",
                table: "J_Tasks",
                newName: "comment");

            migrationBuilder.AlterColumn<int>(
                name: "point",
                table: "J_Transport_Rent",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "element",
                table: "J_Transport_Rent",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "rent",
                table: "J_Transport_Rent",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "fuelamount",
                table: "J_Transport_Fueling",
                type: "float",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "point",
                table: "J_SnowGuns_Orders",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nchar(15)",
                oldFixedLength: true,
                oldMaxLength: 15,
                oldNullable: true);

            migrationBuilder.AlterColumn<DateOnly>(
                name: "dateon",
                table: "J_SnowGuns_Orders",
                type: "date",
                nullable: true,
                oldClrType: typeof(DateOnly),
                oldType: "date");

            migrationBuilder.AddColumn<int>(
                name: "direction",
                table: "J_SnowGuns_Orders",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "gun_id",
                table: "J_SnowGuns_Orders",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "main_point",
                table: "J_SnowGuns_Orders",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "status",
                table: "J_SnowGuns_Orders",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<DateTime>(
                name: "dateOn",
                table: "D_Goods",
                type: "datetime",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<decimal>(
                name: "remain",
                table: "D_Goods",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddPrimaryKey(
                name: "PK_J_SnowGuns_Orders",
                table: "J_SnowGuns_Orders",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_D_Goods_Types",
                table: "D_Goods_Types",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_D_Goods",
                table: "D_Goods",
                column: "id");

            migrationBuilder.CreateTable(
                name: "D_Goods_KB",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    guid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    relatedobject = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    filepath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    description = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_D_Goods_KB", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "D_Infra_Elements_KB",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    guid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    relatedobject = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    filepath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    description = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_D_Infra_Elements_KB", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "D_Staff_KB",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    guid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    relatedobject = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    filepath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    description = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_D_Staff_KB", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "D_Tasks_KB",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    guid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    relatedobject = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    filepath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    description = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_D_Tasks_KB", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "J_Goods",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Task = table.Column<int>(type: "int", nullable: true),
                    Element = table.Column<int>(type: "int", nullable: true),
                    DateOn = table.Column<DateTime>(type: "datetime", nullable: false),
                    Good = table.Column<int>(type: "int", nullable: true),
                    Source = table.Column<int>(type: "int", nullable: true),
                    SourceAddr = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: false),
                    Destination = table.Column<int>(type: "int", nullable: true),
                    DestinationAddr = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    UserWho = table.Column<int>(type: "int", nullable: false),
                    UserWhom = table.Column<int>(type: "int", nullable: true),
                    Type = table.Column<bool>(type: "bit", nullable: false),
                    Qty = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false),
                    DelUser = table.Column<int>(type: "int", nullable: true),
                    DelDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Remain = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_J_Goods", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "D_Goods_KB");

            migrationBuilder.DropTable(
                name: "D_Infra_Elements_KB");

            migrationBuilder.DropTable(
                name: "D_Staff_KB");

            migrationBuilder.DropTable(
                name: "D_Tasks_KB");

            migrationBuilder.DropTable(
                name: "J_Goods");

            migrationBuilder.DropPrimaryKey(
                name: "PK_J_SnowGuns_Orders",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropPrimaryKey(
                name: "PK_D_Goods_Types",
                table: "D_Goods_Types");

            migrationBuilder.DropPrimaryKey(
                name: "PK_D_Goods",
                table: "D_Goods");

            migrationBuilder.DropColumn(
                name: "rent",
                table: "J_Transport_Rent");

            migrationBuilder.DropColumn(
                name: "fuelamount",
                table: "J_Transport_Fueling");

            migrationBuilder.DropColumn(
                name: "direction",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropColumn(
                name: "gun_id",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropColumn(
                name: "main_point",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropColumn(
                name: "status",
                table: "J_SnowGuns_Orders");

            migrationBuilder.DropColumn(
                name: "dateOn",
                table: "D_Goods");

            migrationBuilder.DropColumn(
                name: "remain",
                table: "D_Goods");

            migrationBuilder.RenameColumn(
                name: "gasstation",
                table: "J_Transport_Fueling",
                newName: "task");

            migrationBuilder.RenameColumn(
                name: "fueltype",
                table: "J_Transport_Fueling",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "comment",
                table: "J_Tasks",
                newName: "Comment");

            migrationBuilder.AlterColumn<int>(
                name: "point",
                table: "J_Transport_Rent",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "element",
                table: "J_Transport_Rent",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "good",
                table: "J_Transport_Fueling",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "point",
                table: "J_Transport_Fueling",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "started",
                table: "J_Transport_Fueling",
                type: "datetime",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "point",
                table: "J_SnowGuns_Orders",
                type: "nchar(15)",
                fixedLength: true,
                maxLength: 15,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateOnly>(
                name: "dateon",
                table: "J_SnowGuns_Orders",
                type: "date",
                nullable: false,
                defaultValue: new DateOnly(1, 1, 1),
                oldClrType: typeof(DateOnly),
                oldType: "date",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "code",
                table: "J_SnowGuns_Orders",
                type: "nchar(15)",
                fixedLength: true,
                maxLength: 15,
                nullable: true);

            migrationBuilder.AddColumn<byte>(
                name: "dayOrder",
                table: "J_SnowGuns_Orders",
                type: "tinyint",
                nullable: true);

            migrationBuilder.AddColumn<byte>(
                name: "nightorder",
                table: "J_SnowGuns_Orders",
                type: "tinyint",
                nullable: true);
        }
    }
}
